#!/bin/bash

#Since we will probably need to vary the mesh, it'll be nice to script this process upfront.
#The input arguments expected at this point are:
#  1st - the number of FUEL meshes.  The number must be divisible by 3 since we want the control
#        rod to fall on the mesh boundary at certain points.
#The script will process the necessary materials, pinmeshs, mod_dim, pins, modules, lattices, assemblies
# and transient blocks for all of the 5 cases.

if [[ "$#" -ge "1" ]]; then
  #Check if the input is divisible by 3
  : $((nfp = $1 % 3))
  if [[ "$nfp" == "0" ]]; then
    nfp=$1
    timestep="0.02"
    partition='PLANE'
    if [[ "$#" == "2" ]]; then
      timestep=$2
    fi
    if [[ "$#" == "3" ]]; then
      timestep=$2
      partition=$3
    fi
    #Create the geometry (if it doesn't already exist!)
    geomfilename="base_c5g7_3Dgeom_nfp$nfp.inp"
    #Get the number of guide tube levels
    : $((nzgt = $nfp * 2 / 3))
    #Get the 1/3 inserted level
    : $((onehalfnzgt = $nfp * 1 / 3))
    #Get the module height!  Need awk for floating point stuff...
    modz=$(awk -v dividend="128.52" -v divisor="${nfp}" 'BEGIN {printf "%.6f", dividend/divisor; exit(0)}')
    nrefl=$(awk -v dividend="21.42" -v divisor="${modz}" 'BEGIN {printf "%i", dividend/divisor; exit(0)}')
    nplanes=$(awk -v a="${nrefl}" -v b="${nfp}" 'BEGIN {printf "%i", 2*a+b; exit(0)}')
    #control rod velocity
    crV=21.42
    #If it doesn't exist, create it!
    echo  "Creating base geom file $geomfilename..."
    if [[ ! -f "$geomfilename" ]]; then
      #Get the number of lower fuel regions (that won't be rodded)
      : $((nlowfuel = $nfp * 1 / 3))
      #module dims and pinmeshes are constant.
      echo " !Ray tracing module dimensions" > $geomfilename
      echo " mod_dim 1.26 1.26 $modz" >> $geomfilename
      echo "" >> $geomfilename
      echo " !Pin Mesh" >> $geomfilename
      echo "  pinMesh 1 cyl 0.540 0.62 / 1.26 / $modz / 5 2 / 5*8 2*8 8 / 1   !Pin mesh" >> $geomfilename
      echo "  pinMesh 2 rec 1.26 / 1.26 / $modz / 5 / 5 / 1                   !Reflector mesh" >> $geomfilename
      #Loop over assemblies to set up pins.  The only pins that need an axial dependence are the guide tubes.
      ia=1
      while [[ $ia -le 4 ]]; do
        echo "" >> $geomfilename
        echo " !Assembly $ia pins" >> $geomfilename
        echo " pin "$ia"1 1 / "$ia"1 "$ia"6 "$ia"6 !UO2-3.3 Pin" >> $geomfilename
        echo " pin "$ia"2 1 / "$ia"2 "$ia"6 "$ia"6 !MOX-4.3 Pin" >> $geomfilename
        echo " pin "$ia"3 1 / "$ia"3 "$ia"6 "$ia"6 !MOX-7.0 Pin" >> $geomfilename
        echo " pin "$ia"4 1 / "$ia"4 "$ia"6 "$ia"6 !MOX-8.7 Pin" >> $geomfilename
        echo " pin "$ia"5 1 / "$ia"5 "$ia"6 "$ia"6 !Fission Chamber Pin" >> $geomfilename
        echo " pin "$ia"6 2 / "$ia"8   !Reflector pin" >> $geomfilename
        echo " pin "$ia"7 1 / "$ia"7 "$ia"6 "$ia"6 !Control Rod" >> $geomfilename
        iz=0
        #loop over all the heights for the guide tube.
        while [[ $iz -le $nzgt ]]; do
          echo " pin "$ia"0"$iz" 1 / "$ia"0"$iz" "$ia"6 "$ia"6 !Guide Tube Pin" >> $geomfilename
          let iz+=1
        done
        let ia+=1 
      done
      echo " !Reflector pins" >> $geomfilename
      echo " pin 56 2 / 56     !Reflector pin" >> $geomfilename
      echo "" >> $geomfilename
      echo " !Pin modular ray tracing" >> $geomfilename
      #Loop over assemblies to set up modules.  
      ia=1
      while [[ $ia -le 4 ]]; do
        echo "" >> $geomfilename
        echo " !Assembly $ia modules" >> $geomfilename
        #Loop over the 7 types of materials, excluding guide tubes.
        im=1
        while [[ $im -le 7 ]]; do
          echo " module $ia$im 3*1" >> $geomfilename
          echo "   $ia$im" >> $geomfilename
          let im+=1
        done
        iz=0
        #loop over all the heights for the guide tube.
        while [[ $iz -le $nzgt ]]; do
          echo " module "$ia"0"$iz" 3*1" >> $geomfilename
          echo "   "$ia"0"$iz >> $geomfilename
          let iz+=1
        done
        let ia+=1
      done
      echo " !Reflector Modules" >> $geomfilename
      echo " module 56 3*1" >> $geomfilename
      echo "   56" >> $geomfilename
      #Loop over assemblies to set up lattices.  Good times.
      ia=1
      while [[ $ia -le 4 ]]; do
        echo "" >> $geomfilename
        echo " !Assembly $ia lattices" >> $geomfilename
        #UO2 lattices
        iz=0
        while [[ $iz -le $nzgt ]]; do
          echo "" >> $geomfilename
          if [[ $ia -eq 1 ]] || [[ $ia -eq 4 ]]; then
            echo " lattice $ia$iz 2*17 !UO2 assem $ia" >> $geomfilename
            f="$ia"1"  "
            g="$ia"0"$iz "
            c="$ia"5"  "
            echo "  $f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f" >> $geomfilename
            echo "  $f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f" >> $geomfilename
            echo "  $f$f$f$f$f$g$f$f$g$f$f$g$f$f$f$f$f" >> $geomfilename
            echo "  $f$f$f$g$f$f$f$f$f$f$f$f$f$g$f$f$f" >> $geomfilename
            echo "  $f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f" >> $geomfilename
            echo "  $f$f$g$f$f$g$f$f$g$f$f$g$f$f$g$f$f" >> $geomfilename
            echo "  $f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f" >> $geomfilename
            echo "  $f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f" >> $geomfilename
            echo "  $f$f$g$f$f$g$f$f$c$f$f$g$f$f$g$f$f" >> $geomfilename
            echo "  $f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f" >> $geomfilename
            echo "  $f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f" >> $geomfilename
            echo "  $f$f$g$f$f$g$f$f$g$f$f$g$f$f$g$f$f" >> $geomfilename
            echo "  $f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f" >> $geomfilename
            echo "  $f$f$f$g$f$f$f$f$f$f$f$f$f$g$f$f$f" >> $geomfilename
            echo "  $f$f$f$f$f$g$f$f$g$f$f$g$f$f$f$f$f" >> $geomfilename
            echo "  $f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f" >> $geomfilename
            echo "  $f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f" >> $geomfilename
          #MOX lattices
          else
            echo " lattice $ia$iz 2*17 !MOX assem $ia" >> $geomfilename
            d="$ia"2"  "
            e="$ia"3"  "
            f="$ia"4"  "
            g="$ia"0"$iz "
            c="$ia"5"  "
            echo "  $d$d$d$d$d$d$d$d$d$d$d$d$d$d$d$d$d" >> $geomfilename
            echo "  $d$e$e$e$e$e$e$e$e$e$e$e$e$e$e$e$d" >> $geomfilename
            echo "  $d$e$e$e$e$g$e$e$g$e$e$g$e$e$e$e$d" >> $geomfilename
            echo "  $d$e$e$g$e$e$e$e$e$e$e$e$e$g$e$e$d" >> $geomfilename
            echo "  $d$e$e$e$e$e$e$e$e$e$e$e$e$e$e$e$d" >> $geomfilename
            echo "  $d$e$g$e$e$g$e$e$g$e$e$g$e$e$g$e$d" >> $geomfilename
            echo "  $d$e$e$e$e$e$e$e$e$e$e$e$e$e$e$e$d" >> $geomfilename
            echo "  $d$e$e$e$e$e$e$e$e$e$e$e$e$e$e$e$d" >> $geomfilename
            echo "  $d$e$g$e$e$g$e$e$c$e$e$g$e$e$g$e$d" >> $geomfilename
            echo "  $d$e$e$e$e$e$e$e$e$e$e$e$e$e$e$e$d" >> $geomfilename
            echo "  $d$e$e$e$e$e$e$e$e$e$e$e$e$e$e$e$d" >> $geomfilename
            echo "  $d$e$g$e$e$g$e$e$g$e$e$g$e$e$g$e$d" >> $geomfilename
            echo "  $d$e$e$e$e$e$e$e$e$e$e$e$e$e$e$e$d" >> $geomfilename
            echo "  $d$e$e$g$e$e$e$e$e$e$e$e$e$g$e$e$d" >> $geomfilename
            echo "  $d$e$e$e$e$g$e$e$g$e$e$g$e$e$e$e$d" >> $geomfilename
            echo "  $d$e$e$e$e$e$e$e$e$e$e$e$e$e$e$e$d" >> $geomfilename
            echo "  $d$d$d$d$d$d$d$d$d$d$d$d$d$d$d$d$d" >> $geomfilename
          fi
          let iz+=1
        done
        #Hardcode the reflectors to 1000 and 1001
        echo "" >> $geomfilename
        echo " lattice "$ia"000 2*17 !Lower Reflector Assem $ia" >> $geomfilename
        f="$ia"6"  "
        g="$ia"6"  "
        c="$ia"6"  "
        echo "  $f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f" >> $geomfilename
        echo "  $f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f" >> $geomfilename
        echo "  $f$f$f$f$f$g$f$f$g$f$f$g$f$f$f$f$f" >> $geomfilename
        echo "  $f$f$f$g$f$f$f$f$f$f$f$f$f$g$f$f$f" >> $geomfilename
        echo "  $f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f" >> $geomfilename
        echo "  $f$f$g$f$f$g$f$f$g$f$f$g$f$f$g$f$f" >> $geomfilename
        echo "  $f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f" >> $geomfilename
        echo "  $f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f" >> $geomfilename
        echo "  $f$f$g$f$f$g$f$f$c$f$f$g$f$f$g$f$f" >> $geomfilename
        echo "  $f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f" >> $geomfilename
        echo "  $f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f" >> $geomfilename
        echo "  $f$f$g$f$f$g$f$f$g$f$f$g$f$f$g$f$f" >> $geomfilename
        echo "  $f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f" >> $geomfilename
        echo "  $f$f$f$g$f$f$f$f$f$f$f$f$f$g$f$f$f" >> $geomfilename
        echo "  $f$f$f$f$f$g$f$f$g$f$f$g$f$f$f$f$f" >> $geomfilename
        echo "  $f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f" >> $geomfilename
        echo "  $f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f" >> $geomfilename
        echo "" >> $geomfilename
        echo " lattice "$ia"001 2*17 !Upper Reflector Assem $ia" >> $geomfilename
        f="$ia"6"  "
        g="$ia"7"  "
        c="$ia"5"  "
        echo "  $f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f" >> $geomfilename
        echo "  $f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f" >> $geomfilename
        echo "  $f$f$f$f$f$g$f$f$g$f$f$g$f$f$f$f$f" >> $geomfilename
        echo "  $f$f$f$g$f$f$f$f$f$f$f$f$f$g$f$f$f" >> $geomfilename
        echo "  $f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f" >> $geomfilename
        echo "  $f$f$g$f$f$g$f$f$g$f$f$g$f$f$g$f$f" >> $geomfilename
        echo "  $f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f" >> $geomfilename
        echo "  $f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f" >> $geomfilename
        echo "  $f$f$g$f$f$g$f$f$c$f$f$g$f$f$g$f$f" >> $geomfilename
        echo "  $f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f" >> $geomfilename
        echo "  $f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f" >> $geomfilename
        echo "  $f$f$g$f$f$g$f$f$g$f$f$g$f$f$g$f$f" >> $geomfilename
        echo "  $f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f" >> $geomfilename
        echo "  $f$f$f$g$f$f$f$f$f$f$f$f$f$g$f$f$f" >> $geomfilename
        echo "  $f$f$f$f$f$g$f$f$g$f$f$g$f$f$f$f$f" >> $geomfilename
        echo "  $f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f" >> $geomfilename
        echo "  $f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f" >> $geomfilename
        let ia+=1
      done
      echo "" >> $geomfilename
      #Hardcode the reflectors to 1000 and 1001  This lattice is for assembly 5, reflector
      echo " lattice 5000 2*17 !Outer Reflector Assem $ia" >> $geomfilename
      f="$ia"6"  "
      g="$ia"6"  "
      c="$ia"6"  "
      echo "  $f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f" >> $geomfilename
      echo "  $f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f" >> $geomfilename
      echo "  $f$f$f$f$f$g$f$f$g$f$f$g$f$f$f$f$f" >> $geomfilename
      echo "  $f$f$f$g$f$f$f$f$f$f$f$f$f$g$f$f$f" >> $geomfilename
      echo "  $f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f" >> $geomfilename
      echo "  $f$f$g$f$f$g$f$f$g$f$f$g$f$f$g$f$f" >> $geomfilename
      echo "  $f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f" >> $geomfilename
      echo "  $f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f" >> $geomfilename
      echo "  $f$f$g$f$f$g$f$f$c$f$f$g$f$f$g$f$f" >> $geomfilename
      echo "  $f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f" >> $geomfilename
      echo "  $f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f" >> $geomfilename
      echo "  $f$f$g$f$f$g$f$f$g$f$f$g$f$f$g$f$f" >> $geomfilename
      echo "  $f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f" >> $geomfilename
      echo "  $f$f$f$g$f$f$f$f$f$f$f$f$f$g$f$f$f" >> $geomfilename
      echo "  $f$f$f$f$f$g$f$f$g$f$f$g$f$f$f$f$f" >> $geomfilename
      echo "  $f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f" >> $geomfilename
      echo "  $f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f$f" >> $geomfilename
      echo "" >> $geomfilename
      #Loop over assemblies to set up assemblies.  nearly there.
      ia=1
      while [[ $ia -le 4 ]]; do
        #Get the upper lattices together into one variable string.  
        #(Start at 1 since that is where the rod movement is)
        iz=1
        upfuel=''
        while [[ $iz -le $nzgt ]]; do
          upfuel="$upfuel $ia$iz"
          let iz+=1
        done
        echo "" >> $geomfilename
        echo "  assembly $ia " >> $geomfilename
        echo "   $nrefl*"$ia"000 $nlowfuel*"$ia"0"$upfuel" $nrefl*"$ia"001" >> $geomfilename
        let ia+=1
      done
      echo "" >> $geomfilename
      echo "  assembly 5 " >> $geomfilename
      echo "   $nrefl*5000 $nlowfuel*5000 $nzgt*5000 $nrefl*5000" >> $geomfilename
      echo "" >> $geomfilename
      echo "  core 360" >> $geomfilename
      echo "    1  2  5" >> $geomfilename
      echo "    3  4  5" >> $geomfilename
      echo "    5  5  5" >> $geomfilename
    fi  #If-block for geom file creation

    #Now to set up TD4 inputs...
    #loop over the 5 cases...
    dt=$(awk -v dividend="${modz}" -v divisor="${crV}" 'BEGIN {printf "%.5f", dividend/divisor; exit(0)}')
    dttimestepcheck=$(awk -v dividend="${dt}" -v divisor="${timestep}" 'BEGIN {printf "%.5f", dividend/divisor; exit(0)}')
    dttimestepcheck=`echo $dttimestepcheck | cut -d"." -f2`
    if [[ $dttimestepcheck == "00000" ]]; then
      ic=1
      while [[ $ic -le 5 ]]; do
        ifilepath=./3D/"TD4-"$ic
        if [[ ! -d ./3D/"TD4-"$ic ]]; then
          mkdir ./3D/"TD4-"$ic
        fi
        #Make the input file name (TD4-$ic_$nfp.inp)
        ifilename="TD4-"$ic"_"$nfp".inp"
        ifullpath=$ifilepath/$ifilename
        echo "Creating file $ifullpath..."
        #If the file doesn't exist, create it!
        if [[ ! -f $ifullpath ]]; then
          echo "CASEID c5g7_3D" > $ifullpath
          echo "" >> $ifullpath
          #Write all the materials
          echo "MATERIAL" >> $ifullpath
          ia=1
          while [[ $ia -le 4 ]]; do
            echo " !Assembly $ia mats" >> $ifullpath
            echo "  mat  "$ia"1 2 :: UO2-3.3" >> $ifullpath
            echo "  mat  "$ia"2 2 :: MOX-4.3" >> $ifullpath
            echo "  mat  "$ia"3 2 :: MOX-7.0" >> $ifullpath
            echo "  mat  "$ia"4 2 :: MOX-8.7" >> $ifullpath
            echo "  mat  "$ia"5 2 :: FissCham" >> $ifullpath
            echo "  mat  "$ia"6 0 :: Moderator" >> $ifullpath
            echo "  mat  "$ia"7 0 :: CRod" >> $ifullpath
            echo "  mat  "$ia"8 0 :: Moderator" >> $ifullpath
            echo "  mat  "$ia"61 0 :: MixMod95" >> $ifullpath
            echo "  mat  "$ia"62 0 :: MixMod90" >> $ifullpath
            echo "  mat  "$ia"63 0 :: MixMod85" >> $ifullpath
            echo "  mat  "$ia"64 0 :: MixMod80" >> $ifullpath
            iz=0
            while [[ $iz -le $nzgt ]]; do
              echo "  mat  $ia"0"$iz 0 :: GuideTube" >> $ifullpath
              let iz+=1
            done
            let ia+=1
          done
          echo " !Reflector Assembly mats" >> $ifullpath
          echo "  mat  56 0 :: Moderator" >> $ifullpath
          echo "" >> $ifullpath
          echo "GEOM" >> $ifullpath
          echo " file ../../$geomfilename" >> $ifullpath
          echo "" >> $ifullpath
          echo "XSEC" >> $ifullpath
          echo " addpath ../../" >> $ifullpath 
          echo " xslib USER c5g7_trans_groupv.xsl" >> $ifullpath 
          echo "" >> $ifullpath 
          echo "OPTION" >> $ifullpath 
          echo "  bound_cond 1 1 0 0 0 0" >> $ifullpath 
          echo "  solver 1 2" >> $ifullpath 
          echo "  ray 0.05 CHEBYSHEV-YAMAMOTO  8 2" >> $ifullpath 
          if [[ $partition == "PLANE" ]]; then
            echo "  parallel $nplanes 1 1 1 BLOCK 51 51 1" >> $ifullpath 
          elif [[ $partition == "ASSEM" ]]; then
            let "$nplanes *= 9"
            echo "  parallel $nplanes 1 1 1 BLOCK 17 17 1" >> $ifullpath
          elif [[ $partition == "PIN" ]]; then
            let "$nplanes *= 2601"
            echo "  parallel $nplanes 1 1 1 BLOCK 1 1 1" >> $ifullpath
          fi 
          echo "  conv_crit 2*1.e-6" >> $ifullpath 
          echo "  iter_lim 2000 2 3" >> $ifullpath
          echo "  vis_edits F F" >> $ifullpath
          echo "  scatt_meth TCP0" >> $ifullpath
          echo "  cmfd T MGNODE" >> $ifullpath
          echo "  validation F" >> $ifullpath
          echo "" >> $ifullpath 
          echo "TRANS" >> $ifullpath 
          echo "  enable T" >> $ifullpath
          echo "  time 15.0 / $timestep" >> $ifullpath
          echo "  method theta 0.5" >> $ifullpath
          echo "  multilevel  T  5 10" >> $ifullpath
          tstt="0.0"
          tstp=$dt
          iz=$nzgt
          iz2=$nzgt
          #Insert and withdraw of bank 1 at 0s
          if [[ $ic -eq 1 ]]; then
            #loop over all the guide tube regions.
            while [[ $iz -gt $onehalfnzgt ]]; do
              echo "  perturb $tstt $tstp RAMP 1 / 10$iz 10$iz 17" >> $ifullpath
              tstt=$tstp
              tstp=$(awk -v arg1="${tstp}" -v arg2="${dt}" 'BEGIN {printf "%.5f", arg1+arg2; exit(0)}')
              let iz-=1
            done
            let iz+=1
            while [[ $iz -le $nzgt ]]; do
              echo "  perturb $tstt $tstp RAMP 1 / 10$iz 17 10$iz " >> $ifullpath
              tstt=$tstp
              tstp=$(awk -v arg1="${tstp}" -v arg2="${dt}" 'BEGIN {printf "%.5f", arg1+arg2; exit(0)}')
              let iz+=1
            done
            let iz-=1
            tstp=$(awk -v arg1="${tstp}" -v arg2="${dt}" 'BEGIN {printf "%.5f", arg1-arg2; exit(0)}')
            echo "  perturb $tstp 15.0 RAMP 1 / 10$iz 10$iz 10$iz " >> $ifullpath
            echo "  " >> $ifullpath
          #Insert and withdraw of bank 3 at 0s
          elif [[ $ic -eq 2 ]]; then
            #loop over all the guide tube regions.
            while [[ $iz -ge 1 ]]; do
              echo "  perturb $tstt $tstp RAMP 1 / 30$iz 30$iz 37" >> $ifullpath
              tstt=$tstp
              tstp=$(awk -v arg1="${tstp}" -v arg2="${dt}" 'BEGIN {printf "%.5f", arg1+arg2; exit(0)}')
              let iz-=1
            done
            let iz+=1
            while [[ $iz -le $nzgt ]]; do
              echo "  perturb $tstt $tstp RAMP 1 / 30$iz 37 30$iz " >> $ifullpath
              tstt=$tstp
              tstp=$(awk -v arg1="${tstp}" -v arg2="${dt}" 'BEGIN {printf "%.5f", arg1+arg2; exit(0)}')
              let iz+=1
            done
            let iz-=1
            tstp=$(awk -v arg1="${tstp}" -v arg2="${dt}" 'BEGIN {printf "%.5f", arg1-arg2; exit(0)}')
            echo "  perturb $tstp 15.0 RAMP 1 / 30$iz 30$iz 30$iz " >> $ifullpath
            echo "  " >> $ifullpath
          #Insert and withdraw bank 3 at 0s and insert and withdraw bank 1 at 2s.
          elif [[ $ic -eq 3 ]]; then
            #loop over all the guide tube regions.  iz is for bank 1, iz2 is for bank 3
            nramp=1
            while [[ $iz2 -ge 1 ]]; do
              #Check to see if the time is >= 2s to start printing bank1...
              lbool=$(awk -v arg1="${tstt}" -v arg2="2.0" 'BEGIN {printf arg1>=arg2?1:0; exit(0)}')
              if [[ "$lbool" -eq "1" ]] && [[ "$nramp" -eq "1" ]]; then
                nramp=2
              fi
              echo "  perturb $tstt $tstp RAMP $nramp / 30$iz2 30$iz2 37" >> $ifullpath
              if [[ "$lbool" -eq "1" ]]; then
                echo "                                   10$iz 10$iz 17" >> $ifullpath
                let iz-=1
              fi
              tstt=$tstp
              tstp=$(awk -v arg1="${tstp}" -v arg2="${dt}" 'BEGIN {printf "%.5f", arg1+arg2; exit(0)}')
              let iz2-=1
            done
            let iz2+=1
            let iz+=1
            while [[ $iz2 -le $nzgt ]]; do
              #Check to see if the time is >= 6s to stop printing bank1...
              lbool=$(awk -v arg1="${tstt}" -v arg2="6.0" 'BEGIN {printf arg1>=arg2?1:0; exit(0)}')
              if [[ "$lbool" -eq "1" ]] && [[ "$nramp" -eq "2" ]]; then
                nramp=1
              fi
              echo "  perturb $tstt $tstp RAMP $nramp / 30$iz2 37 30$iz2 " >> $ifullpath
              if [[ "$lbool" -eq "0" ]]; then
                echo "                                   10$iz 17 10$iz" >> $ifullpath
                let iz+=1
              fi
              tstt=$tstp
              tstp=$(awk -v arg1="${tstp}" -v arg2="${dt}" 'BEGIN {printf "%.5f", arg1+arg2; exit(0)}')
              let iz2+=1
            done
            let iz2-=1
            tstp=$(awk -v arg1="${tstp}" -v arg2="${dt}" 'BEGIN {printf "%.5f", arg1-arg2; exit(0)}')
            echo "  perturb $tstp 15.0 RAMP 1 / 30$iz2 30$iz2 30$iz2 " >> $ifullpath
            echo "  " >> $ifullpath
          #Insert and withdraw bank 4 at 0s, insert and withdraw bank 3 at 2s
          elif [[ $ic -eq 4 ]]; then
            #loop over all the guide tube regions.  iz is for bank 1, iz2 is for bank 3
            nramp=1
            while [[ $iz2 -ge 1 ]]; do
              #Check to see if the time is >= 2s to start printing bank1...
              lbool=$(awk -v arg1="${tstt}" -v arg2="2.0" 'BEGIN {printf arg1>=arg2?1:0; exit(0)}')
              if [[ "$lbool" -eq "1" ]] && [[ "$nramp" -eq "1" ]]; then
                nramp=2
              fi
              echo "  perturb $tstt $tstp RAMP $nramp / 40$iz2 40$iz2 47" >> $ifullpath
              if [[ "$lbool" -eq "1" ]]; then
                echo "                                   30$iz 30$iz 37" >> $ifullpath
                let iz-=1
              fi
              tstt=$tstp
              tstp=$(awk -v arg1="${tstp}" -v arg2="${dt}" 'BEGIN {printf "%.5f", arg1+arg2; exit(0)}')
              let iz2-=1
            done
            let iz2+=1
            let iz+=1
            while [[ $iz2 -le $nzgt ]]; do
              #Check to see if the time is >= 6s to stop printing bank1...
              lbool=$(awk -v arg1="${tstt}" -v arg2="6.0" 'BEGIN {printf arg1>=arg2?1:0; exit(0)}')
              if [[ "$lbool" -eq "1" ]] && [[ "$nramp" -eq "2" ]]; then
                nramp=1
              fi
              echo "  perturb $tstt $tstp RAMP $nramp / 40$iz2 47 40$iz2 " >> $ifullpath
              if [[ "$lbool" -eq "0" ]]; then
                echo "                                   30$iz 37 30$iz" >> $ifullpath
                let iz+=1
              fi
              tstt=$tstp
              tstp=$(awk -v arg1="${tstp}" -v arg2="${dt}" 'BEGIN {printf "%.5f", arg1+arg2; exit(0)}')
              let iz2+=1
            done
            let iz2-=1
            tstp=$(awk -v arg1="${tstp}" -v arg2="${dt}" 'BEGIN {printf "%.5f", arg1-arg2; exit(0)}')
            echo "  perturb $tstp 15.0 RAMP 1 / 40$iz2 40$iz2 40$iz2 " >> $ifullpath
            echo "  " >> $ifullpath
          #Insert and withdraw bank 1 at 0s, insert, hold, withdraw bank 3 at 2s.
          elif [[ $ic -eq 5 ]]; then
            #loop over all the guide tube regions.  iz is for bank 1, iz2 is for bank 3
            nramp=1
            while [[ $iz2 -gt $onehalfnzgt ]]; do
              echo "  perturb $tstt $tstp RAMP $nramp / 10$iz2 10$iz2 17" >> $ifullpath
              tstt=$tstp
              tstp=$(awk -v arg1="${tstp}" -v arg2="${dt}" 'BEGIN {printf "%.5f", arg1+arg2; exit(0)}')
              let iz2-=1
            done
            let iz2+=1
            nramp=2
            loopbool=1
            while [[ $loopbool -eq 1 ]]; do
              #Check to see if the time is >= 6s to stop printing bank1...
              lbool=$(awk -v arg1="${tstt}" -v arg2="4.0" 'BEGIN {printf arg1>=arg2?1:0; exit(0)}')
              lbool2=$(awk -v arg1="${tstt}" -v arg2="6.0" 'BEGIN {printf arg1>=arg2?1:0; exit(0)}')
              loopbool=$(awk -v arg1="${tstp}" -v arg2="8.0" 'BEGIN {printf arg1<arg2?1:0; exit(0)}')
              if [[ "$lbool" -eq "1" ]]; then
                nramp=1
              fi
              if [[ "$lbool" -eq "0" ]]; then
                echo "  perturb $tstt $tstp RAMP $nramp / 30$iz 30$iz 37" >> $ifullpath
                echo "                                   10$iz2 17 10$iz2" >> $ifullpath
                let iz-=1
                let iz2+=1
              elif [[ "$lbool2" -eq "0" ]]; then
                echo "  perturb $tstt $tstp RAMP $nramp / 30$iz 30$iz 30$iz" >> $ifullpath
              else
                let iz+=1
                echo "  perturb $tstt $tstp RAMP $nramp / 30$iz 37 30$iz" >> $ifullpath
              fi
              tstt=$tstp
              tstp=$(awk -v arg1="${tstp}" -v arg2="${dt}" 'BEGIN {printf "%.5f", arg1+arg2; exit(0)}')
            done
            let iz2-=1
            tstp=$(awk -v arg1="${tstp}" -v arg2="${dt}" 'BEGIN {printf "%.5f", arg1-arg2; exit(0)}')
            echo "  perturb $tstp 15.0 RAMP 1 / 30$iz2 30$iz2 30$iz2 " >> $ifullpath
            echo "  " >> $ifullpath
          fi
          echo "" >> $ifullpath 
        fi
        let ic+=1
      done
    else
      echo "The delta t $dt for the transient perturbations is not divisible by the time step $timestep!"
    fi
    #How to set up loops...
    #Only need to create the geom file once.  No need for a loop.
    #  Get the starting and stopping fuel indices.
    #  Make the reflectors, cause they're easy.
    #  A loop for each assembly, for all pins
    #  A loop for each assembly, for all modules
    #  A loop for each assembly, for all lattices.
    #Need a loop over the 5 cases somewhere
    #  within that, need a loop over materials (materials will be the same across all cases)
    #  also need a loop for the transient block stuff.
  else
    echo "The number of fuel planes must be divisible by 3!"
  fi
else
  echo "Specify the number of fuel planes!"
fi

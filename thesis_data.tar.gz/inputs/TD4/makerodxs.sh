#!/bin/bash

filename=roddedxs.xsl
#set up the gt and cr xs's
abgt[1]='5.11320E-04'
abgt[2]='7.58010E-05'
abgt[3]='3.15720E-04'
abgt[4]='1.15820E-03'
abgt[5]='3.39750E-03'
abgt[6]='9.18780E-03'
abgt[7]='2.32420E-02'
s1gt[1]='6.61659E-02'
s1gt[2]='0.00000E+00'
s1gt[3]='0.00000E+00'
s1gt[4]='0.00000E+00'
s1gt[5]='0.00000E+00'
s1gt[6]='0.00000E+00'
s1gt[7]='0.00000E+00'
s2gt[1]='5.90700E-02'
s2gt[2]='2.40377E-01'
s2gt[3]='0.00000E+00'
s2gt[4]='0.00000E+00'
s2gt[5]='0.00000E+00'
s2gt[6]='0.00000E+00'
s2gt[7]='0.00000E+00'
s3gt[1]='2.83340E-04'
s3gt[2]='5.24350E-02'
s3gt[3]='1.83297E-01'
s3gt[4]='0.00000E+00'
s3gt[5]='0.00000E+00'
s3gt[6]='0.00000E+00'
s3gt[7]='0.00000E+00'
s4gt[1]='1.46220E-06'
s4gt[2]='2.49900E-04'
s4gt[3]='9.23970E-02'
s4gt[4]='7.88511E-02'
s4gt[5]='3.73330E-05'
s4gt[6]='0.00000E+00'
s4gt[7]='0.00000E+00'
s5gt[1]='2.06420E-08'
s5gt[2]='1.92390E-05'
s5gt[3]='6.94460E-03'
s5gt[4]='1.70140E-01'
s5gt[5]='9.97372E-02'
s5gt[6]='9.17260E-04'
s5gt[7]='0.00000E+00'
s6gt[1]='0.00000E+00'
s6gt[2]='2.98750E-06'
s6gt[3]='1.08030E-03'
s6gt[4]='2.58810E-02'
s6gt[5]='2.06790E-01'
s6gt[6]='3.16765E-01'
s6gt[7]='4.97920E-02'
s7gt[1]='0.00000E+00'
s7gt[2]='4.21400E-07'
s7gt[3]='2.05670E-04'
s7gt[4]='4.92970E-03'
s7gt[5]='2.44780E-02'
s7gt[6]='2.38770E-01'
s7gt[7]='1.09912E+00'

abcr[1]='1.70490E-03'
abcr[2]='8.36224E-03'
abcr[3]='8.37901E-02'
abcr[4]='3.97797E-01'
abcr[5]='6.98763E-01'
abcr[6]='9.29508E-01'
abcr[7]='1.17836E+00'
s1cr[1]='1.70563E-01'
s1cr[2]='0.00000E+00'
s1cr[3]='0.00000E+00'
s1cr[4]='0.00000E+00'
s1cr[5]='0.00000E+00'
s1cr[6]='0.00000E+00'
s1cr[7]='0.00000E+00'
s2cr[1]='4.44012E-02'
s2cr[2]='4.71050E-01'
s2cr[3]='0.00000E+00'
s2cr[4]='0.00000E+00'
s2cr[5]='0.00000E+00'
s2cr[6]='0.00000E+00'
s2cr[7]='0.00000E+00'
s3cr[1]='9.83670E-05'
s3cr[2]='6.85480E-04'
s3cr[3]='8.01859E-01'
s3cr[4]='0.00000E+00'
s3cr[5]='0.00000E+00'
s3cr[6]='0.00000E+00'
s3cr[7]='0.00000E+00'
s4cr[1]='1.27786E-07'
s4cr[2]='3.91395E-10'
s4cr[3]='7.20132E-04'
s4cr[4]='5.70752E-01'
s4cr[5]='6.55562E-05'
s4cr[6]='0.00000E+00'
s4cr[7]='0.00000E+00'
s5cr[1]='0.00000E+00'
s5cr[2]='0.00000E+00'
s5cr[3]='0.00000E+00'
s5cr[4]='1.46015E-03'
s5cr[5]='2.07838E-01'
s5cr[6]='1.02427E-03'
s5cr[7]='0.00000E+00'
s6cr[1]='0.00000E+00'
s6cr[2]='0.00000E+00'
s6cr[3]='0.00000E+00'
s6cr[4]='0.00000E+00'
s6cr[5]='3.81486E-03'
s6cr[6]='2.02465E-01'
s6cr[7]='3.53043E-03'
s7cr[1]='0.00000E+00'
s7cr[2]='0.00000E+00'
s7cr[3]='0.00000E+00'
s7cr[4]='0.00000E+00'
s7cr[5]='3.69760E-09'
s7cr[6]='4.75290E-03'
s7cr[7]='6.58597E-01'
#Loop over the fraction
i=1
echo "" > $filename
while [[ $i -le 100 ]]; do
  #calculate the new values for the line
  echo "XSMACRO CRod$i 0" >> $filename
  #absorption XS
  j=1
  while [[ $j -le 7 ]]; do
    ab[1]=$(awk -v g="${abgt[$j]}" -v c="${abcr[$j]}" -v f="$i" 'BEGIN {printf "%.5e", g*(100-f)/100  + c*f/100; exit(0)}')
    echo "  ${ab[1]} 0.00000E+00 0.00000E+00 0.00000E+00" >> $filename
    let j+=1
  done
  #scattering XS
  j=1
  while [[ $j -le 7 ]]; do
    ab[$j]=$(awk -v g="${s1gt[$j]}" -v c="${s1cr[$j]}" -v f="$i" 'BEGIN {printf "%.5e", g*(100-f)/100  + c*f/100; exit(0)}')
    let j+=1
  done
  echo "  ${ab[1]} ${ab[2]} ${ab[3]} ${ab[4]} ${ab[5]} ${ab[6]} ${ab[7]}" >> $filename
  j=1
  while [[ $j -le 7 ]]; do
    ab[$j]=$(awk -v g="${s2gt[$j]}" -v c="${s2cr[$j]}" -v f="$i" 'BEGIN {printf "%.5e", g*(100-f)/100  + c*f/100; exit(0)}')
    let j+=1
  done
  echo "  ${ab[1]} ${ab[2]} ${ab[3]} ${ab[4]} ${ab[5]} ${ab[6]} ${ab[7]}" >> $filename
  j=1
  while [[ $j -le 7 ]]; do
    ab[$j]=$(awk -v g="${s3gt[$j]}" -v c="${s3cr[$j]}" -v f="$i" 'BEGIN {printf "%.5e", g*(100-f)/100  + c*f/100; exit(0)}')
    let j+=1
  done
  echo "  ${ab[1]} ${ab[2]} ${ab[3]} ${ab[4]} ${ab[5]} ${ab[6]} ${ab[7]}" >> $filename
  j=1
  while [[ $j -le 7 ]]; do
    ab[$j]=$(awk -v g="${s4gt[$j]}" -v c="${s4cr[$j]}" -v f="$i" 'BEGIN {printf "%.5e", g*(100-f)/100  + c*f/100; exit(0)}')
    let j+=1
  done
  echo "  ${ab[1]} ${ab[2]} ${ab[3]} ${ab[4]} ${ab[5]} ${ab[6]} ${ab[7]}" >> $filename
   j=1
  while [[ $j -le 7 ]]; do
    ab[$j]=$(awk -v g="${s5gt[$j]}" -v c="${s5cr[$j]}" -v f="$i" 'BEGIN {printf "%.5e", g*(100-f)/100  + c*f/100; exit(0)}')
    let j+=1
  done
  echo "  ${ab[1]} ${ab[2]} ${ab[3]} ${ab[4]} ${ab[5]} ${ab[6]} ${ab[7]}" >> $filename
  j=1
  while [[ $j -le 7 ]]; do
    ab[$j]=$(awk -v g="${s6gt[$j]}" -v c="${s6cr[$j]}" -v f="$i" 'BEGIN {printf "%.5e", g*(100-f)/100  + c*f/100; exit(0)}')
    let j+=1
  done
  echo "  ${ab[1]} ${ab[2]} ${ab[3]} ${ab[4]} ${ab[5]} ${ab[6]} ${ab[7]}" >> $filename
  j=1
  while [[ $j -le 7 ]]; do
    ab[$j]=$(awk -v g="${s7gt[$j]}" -v c="${s7cr[$j]}" -v f="$i" 'BEGIN {printf "%.5e", g*(100-f)/100  + c*f/100; exit(0)}')
    let j+=1
  done
  echo "  ${ab[1]} ${ab[2]} ${ab[3]} ${ab[4]} ${ab[5]} ${ab[6]} ${ab[7]}" >> $filename

  let i+=1 
done

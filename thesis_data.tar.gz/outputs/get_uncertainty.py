#!/usr/bin/python
import numpy as np
import h5py as h5
import sys

nargs = len(sys.argv)
if nargs == 3:
  reffile = h5.File(sys.argv[1],"r")
  refstate = int(sys.argv[2])
else:
  print 'Requies two hdf 5 files, and optionally a state number after each file.'
  sys.exit(1)

refstatestr = str(refstate)

order = 1
while True:
  order = order*10
  if refstate < order:
    refstatestr = '0' + refstatestr
  if order == 1000:
    break

refpowername = '/STATE_' + refstatestr + '/pin_powers'
refaxialname = '/CORE/axial_mesh'

refpower = reffile[refpowername]
refkeff = reffile['/STATE_' + refstatestr + '/keff']
bool = '/STATE_' + refstatestr + '/outers' in reffile
if bool:
  refouter = reffile['/STATE_' + refstatestr + '/outers']
  reftime = reffile['/STATE_' + refstatestr + '/outer_timer']
else:
  refouter = 0
refaxial = reffile[refaxialname]

# Check for sigmas
mcref = '/STATE_' + refstatestr + '/keff_sigma' in reffile
if mcref:
  keffsigma = reffile['/STATE_' + refstatestr + '/keff_sigma']
  refpowersigma = reffile['/STATE_' + refstatestr + '/pin_powers_sigma']

uncertainty = refpower[...]*refpowersigma[...]*0.01

maxx,maxy,maxz,maxasy = np.unravel_index(np.argmax(np.abs(uncertainty)), uncertainty.shape)
print ' Maximum uncertainty: ' + ("%1.6f" % uncertainty[maxx,maxy,maxz,maxasy]) + ', Location: ' + ("%i" % maxx) + ',  ' + ("%i" % maxy) + ', ' + ("%i" % maxz) + ' in assembly ' + ("%i" % maxasy)

print '\n'

#!/bin/bash

echo $@
if [ $# -gt 1 ]
then
  all=$1
  shift
else
  echo "Need yes or no as the first argument!"
  exit
fi
if [ $# -gt 1 ]
then
  ncomp=$1
  shift
else
  echo "Need the number of rod positions as second argument!"
  exit
fi
base=$1
for i in 0 1 2 3
do
  for j in 00 01 02 03 04 05 06 07 08 09 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30
  do
    if [ $j -gt $ncomp ]
    then
      break
    fi
    echo "compare_powers.py c5g7_${base}_ref_${j}.h5 c5g7_${base}_subray_${j}_${i}.h5"
    compare_powers.py c5g7_${base}_ref_${j}.h5 c5g7_${base}_subray_${j}_${i}.h5
  done
done

if [ $all = "yes" ]
then
  for i in none subplane 1dcpm
  do
  for j in 00 01 02 03 04 05 06 07 08 09 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30
    do
      if [ $j -gt $ncomp ]
      then
        break
      fi
      echo "compare_powers.py c5g7_${base}_ref_${j}.h5 c5g7_${base}_${i}_${j}.h5"
      compare_powers.py c5g7_${base}_ref_${j}.h5 c5g7_${base}_${i}_${j}.h5
    done
  done
fi

#!/bin/bash

#Check to see if we want to rerun the reference case
test=1
if [ "$#" -eq 3 ]; then
  if [ "$3" = "no" ]; then
    test=0
  fi
fi
if [ "$test" -eq 1 ]; then
  rm fort.* ref.*
  ./MPACT.exe $1
  rename fort ref fort.*
else
  rm fort.*
fi
./MPACT.exe $2
ref=$(basename "$1")
ref="${ref%.*}"
comp=$(basename "$2")
comp="${comp%.*}"
compare_powers.py ${ref}.h5 ${comp}.h5

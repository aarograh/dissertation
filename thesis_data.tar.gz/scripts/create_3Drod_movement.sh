#!/bin/bash

ref=$1
ref="${ref%.*}"
comp=$2
comp="${comp%.*}"

for i in 00 01 02 03 04 05 06 07 08 09 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30
do
  old=${ref}.inp
  new=${ref}_${i}.inp
  if [ "$i" = "00" ] || [ "$i" = "10" ] || [ "$i" = "20" ] || [ "$i" = 30 ]
  then
    ii=0
  elif [ $i -lt 10 ]
  then
    ii=$(echo $i | sed 's/^0\{1\}//')
  elif [ $i -lt 20 ]
  then
    ii=$(echo $i | sed 's/^1\{1\}//')
  else
    ii=$(echo $i | sed 's/^2\{1\}//')
  fi
  if [ "$i" = "00" ] || [ "$i" = "10" ] || [ "$i" = "20" ] || [ "$i" = 30 ]
  then
    jj=0
  else
    jj="$((10 - ${ii}))"
  fi
  sed "s/CASEID $ref/CASEID ${ref}_${i}/" $old > $new
  sed "s/rodbank A 30 B 30 C 0/rodbank A 30 B 30 C ${i}/" -i $new
  if [ "$i" = "00" ] || [ "$i" = "10" ] || [ "$i" = "20" ] || [ "$i" = 30 ]
  then
    :
  elif [ $i -lt 10 ]
  then
    sed 's,..\(.\) ..\(.\) ..\(.\) \(...\) !lattice labels,'"${ii}"'\1'" ${jj}"'\1  10\2  10\3 \4,g' -i $new
  elif [ $i -lt 20 ]
  then
    sed 's,..\(.\) ..\(.\) ..\(.\) \(...\) !lattice labels,10\1 '"${ii}"'\2 '"${jj}"'\2 10\3 \4,g' -i $new
  else
    sed 's,..\(.\) ..\(.\) ..\(.\) \(...\) !lattice labels,10\1 10\2  '"${ii}"'\3 '"${jj}"'\3 \4,g' -i $new
  fi
  old=${comp}.inp
  new=${comp}_${i}_0.inp
  sed "s/CASEID $comp/CASEID ${comp}_${i}_0/" $old > $new
  sed "s/rodbank A 30 B 30 C 0/rodbank A 30 B 30 C ${i}/" -i $new
  if [ 1 -eq 0 ]
  then
    for j in 1 2
    do
      $old=$new
      new=${comp}_${i}_${j}.inp
      sed "s/moc_kernel 4 0/moc_kernel 4 ${j}/" $old > $new
    done
  fi
done

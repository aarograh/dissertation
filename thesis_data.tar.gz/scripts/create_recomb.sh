#!/bin/bash

nrecomb=$1
shift
inp=$@

for i in $inp
do
  base="${i%_*}_"
  ext="${i##*.}"
  for j in $(seq 1 $nrecomb)
  do
    new=${base}${j}.${ext}
    sed 's,moc_kernel 4 0,moc_kernel 4 '"$j"',g' $i > $new
    sed 's,CASEID '"${base}"'0,CASEID '"${base}${j}"',g' -i $new
  done
done

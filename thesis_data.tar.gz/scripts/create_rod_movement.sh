#!/bin/bash

ref=$1
ref="${ref%.*}"
comp=$2
comp="${comp%.*}"

for i in 00 01 02 03 04 05 06 07 08 09 10
do
  old=${ref}.inp
  new=${ref}_${i}.inp
  if [ "$i" == "00" ]
  then
    ii=0
  else
    ii=$(echo $i | sed 's/^0*//')
  fi
  if [ "$i" == "10" ]
  then
    jj=0
  else
    jj="$((10 - ${ii}))"
  fi
  sed "s/CASEID $ref/CASEID ${ref}_${i}/" $old > $new
  sed "s/rodbank A 10 B 10 C 0/rodbank A 10 B 10 C ${ii}/" -i $new
  if [ "$i" = "00" ]
  then
    :
  elif [ "$i" = "10" ]
  then
    sed 's/..\(.\) ..\(.\) !lattice labels/10\1/' -i $new
  else
    sed 's,..\(.\) ..\(.\) !lattice labels,'"${ii}"'\1 '"${jj}"'\2,g' -i $new
  fi
  old=${comp}.inp
  new=${comp}_${i}_0.inp
  sed "s/CASEID $comp/CASEID ${comp}_${i}_0/" $old > $new
  sed "s/rodbank A 10 B 10 C 0/rodbank A 10 B 10 C ${ii}/" -i $new
  if [ 1 -eq 0 ]
  then
    for j in 1 2
    do
      $old=$new
      new=${comp}_${i}_${j}.inp
      sed "s/moc_kernel 4 0/moc_kernel 4 ${j}/" $old > $new
    done
  fi
done

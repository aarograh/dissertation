#!/bin/bash

inp=$@

for i in $inp
do
  if [ ! -e $(basename $i) ]
  then
    ln -s $i
  fi
done

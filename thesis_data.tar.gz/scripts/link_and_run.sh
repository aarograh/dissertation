#!/bin/bash

inp=$@

for i in $inp
do
  if [ ! -e $(basename $i) ]
  then
    ln -s $i
  fi
  ./MPACT.exe $i
done

for i in $inp
do
  base=$(basename $i)
  base="${base%.*}"
  echo " ${i}: `grep k-eff ${base}.out`"
done

#!/bin/bash

echo $@
inp=("$@")

i=0
while [ $i -lt $# ]
do
  for j in $(seq 1 31)
  do
    if [ $i -lt $# ]
    then
      ./MPACT.exe ${inp[$i]} &
      ((i++))
      sleep 2
    fi
  done
  wait
done

i=0
while [ $i -lt $# ]
do
  base=$(basename ${inp[$i]})
  base="${base%.*}"
  echo "${base}: `grep k-eff ${base}.out`"
  ((i++))
done
